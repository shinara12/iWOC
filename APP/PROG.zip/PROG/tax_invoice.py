from fpdf import FPDF
import pandas as pd
from datetime import datetime
from PIL import Image
from barcode import EAN13,Code39
from barcode.writer import ImageWriter
import pandas as pd

def TAX_INV(request,files1):
    path11 = r'E:\IWOC\SOURCE\\'+ files1
    data=pd.read_excel(path11)
    print(data.columns)
    number_of_rows = len(data)
    df=pd.DataFrame()
    df['INVOICE_NUMBER'] = data['INVOICE_NUMBER']
    df['PRINT DATE'] = data['PRINT DATE']
    df['ILOM_OLD_SEQUENCE'] = data['ILOM_OLD_SEQUENCE']
    df['LNAME'] =  data['LNAME']
    df['ADDR1']=data['ADDR1']
    df['ADDR2']=data['ADDR2']
    df['ADDR3']=data['ADDR3']
    df['ADDR4']=data['ADDR4']
    df['POSTCD']=data['POSTCD']
    df['CITY']=data['CITY']
    df['STATECD']=data['STATECD']
    df['SYSDATE_GENERATE'] = data['SYSDATE_GENERATE']
    df['MEMO_ITEM'] = data['MEMO_ITEM']
    df['MEMO_AMOUNT'] = data['MEMO_AMOUNT']
    df['GST_TAX'] = data['GST_TAX']
    df['TOTAL_AMOUNT_INCLUDED_GST'] = data['TOTAL_AMOUNT_INCLUDED_GST']
    print(df)

    dates = df['SYSDATE_GENERATE'].to_list()
    date1 = []
    for i in dates:
        date1.append(i.strftime('%d%m%y'))
    # print(date1,'sysysysysy')

    def barcode(acc_no,count):
        now = datetime.now() 
        date = now.strftime("%m%d%y")
        barcode_no = '0905' +  str(date) +  str(acc_no) 
        # print("date :",date) 
        # print(barcode_no,'barcode_nobarcode_nobarcode_no')
        

        number = barcode_no
        my_code = Code39(number, writer=ImageWriter())
        new_code  = 'b' + str(count)
        my_code.save(r"E:\IWOC\barcode_for_tax\%s" %(new_code))

        from PIL import Image

        img = Image.open(r"E:\IWOC\barcode_for_tax\%s.png" %(new_code))
        imgCropped = img.crop(box=(4,10,1080,200))
        imgCropped.save(r"E:\IWOC\barcode_for_tax\%s.png" %(new_code))


    count = 1
    pdf = FPDF()
    for i in range(0,number_of_rows):
        barcode(df['ILOM_OLD_SEQUENCE'][i],count)
        now = datetime.now() 
        date = now.strftime("%m%d%y")
        barcode_no1 = '0905' +  str(date1[0]) +  str(df['ILOM_OLD_SEQUENCE'][i])
        print(barcode_no1)
        pdf.add_page()
        pdf.set_auto_page_break(auto=False)
        pdf.set_line_width(6)
        pdf.set_draw_color(r=0, g=0, b=0)
        pdf.line(x1=5, y1=4, x2=205, y2=4)         #1st horizontal line
        pdf.line(x1=5, y1=292, x2=205, y2=292)     #2nd horizontal line 
        pdf.line(5,6,5,290)                         # 1st vertical line
        pdf.line(205,6,205,290)                     # 2nd vertical line    

        pdf.image(r'E:\IWOC\SOURCE\conv_header2.jpg',20,20,30)

        pdf.ln(1)
        pdf.set_font('Arial','B',9)
        pdf.cell(10)
        pdf.cell(10,80,txt ='Tax Invoice No:')

        pdf.cell(14)
        pdf.set_font('Arial','',9)
        pdf.cell(10,80,txt = str(df['INVOICE_NUMBER'][i]))

        pdf.cell(100)
        pdf.set_font('Arial','B',9)
        pdf.cell(10,80,txt = 'Date:')

        pdf.cell(-2)
        pdf.set_font('Arial','',9)
        a = str(df['PRINT DATE'][i]) 
        a = a.split()
        a = a[0]
        pdf.cell(10,80,txt = str(a))

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,84,txt = 'BANK SIMPANAN NASIONAL')

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,88,txt = 'Wisma BSN')

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,92,txt = '117, Jalan Ampang')

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,96,txt = '50450 Kuala Lumpur')

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','B',9)
        pdf.cell(10,101,txt = 'GST ID No:')

        pdf.cell(7)
        pdf.set_font('Arial','B',9)
        pdf.cell(10,101,txt = '001673723904')


        pdf.ln(1)
        pdf.cell(80)
        pdf.set_font('Arial','B',10)
        pdf.cell(10,110,txt = 'TAX INVOICE')

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','B',9)
        pdf.cell(10,125,txt = str(df['ILOM_OLD_SEQUENCE'][i]))

        h = 140
        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,h,txt = str(df['LNAME'][i]))

        if pd.notna(df['ADDR1'][i]):
            h = h + 5
            pdf.ln(1)
            pdf.cell(10)
            pdf.set_font('Arial','',9)
            pdf.cell(10,h,txt = df['ADDR1'][i])

        if pd.notna(df['ADDR2'][i]):
            h = h + 5
            pdf.ln(1)
            pdf.cell(10)
            pdf.set_font('Arial','',9)
            pdf.cell(10,h,txt = str(df['ADDR2'][i]))

        if pd.notna(df['ADDR3'][i]):
            h = h + 5
            pdf.ln(1)
            pdf.cell(10)
            pdf.set_font('Arial','',9)
            pdf.cell(10,h,txt = str(df['ADDR3'][i]))

        if pd.notna(df['ADDR4'][i]):
            h = h + 5    
            pdf.ln(1)
            pdf.cell(10)
            pdf.set_font('Arial','',9)
            pdf.cell(10,h,txt = str(df['ADDR4'][i]))

        if pd.notna(df['POSTCD'][i]):
            h = h + 5
            pdf.ln(1)
            pdf.cell(10)
            pdf.set_font('Arial','',9)
            pdf.cell(10,h,txt = str(df['POSTCD'][i]) + str(df['CITY'][i]))

        if pd.notna(df['STATECD'][i]):
            h = h + 5
            pdf.ln(1)
            pdf.cell(10)
            pdf.set_font('Arial','',9)
            pdf.cell(10,h,txt = str(df['STATECD'][i]) )

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','B',9)
        pdf.cell(10,200,txt = 'No.')

        pdf.cell(-1)
        pdf.cell(10,200,txt = 'Date')

        pdf.cell(12)
        pdf.cell(10,200,txt = 'Description ')

        pdf.cell(38)
        pdf.cell(10,200,txt = 'Tax Rate')

        pdf.cell(12)
        pdf.cell(10,200,txt = 'Amount')

        pdf.cell(10)
        pdf.cell(10,200,txt = 'GST Amount')

        pdf.cell(13)
        pdf.cell(10,200,txt = 'Total Incl GST')

        pdf.ln(1)
        pdf.cell(96)
        pdf.cell(10,205,txt = '(%)')

        pdf.cell(10)
        pdf.cell(10,205,txt = '(RM)')

        pdf.cell(16)
        pdf.cell(10,205,txt = '(RM)')

        pdf.cell(14)
        pdf.cell(10,205,txt = '(RM)')

        pdf.ln(1)
        pdf.set_line_width(0.1)
        pdf.line(20,134,190,134)

        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,230,txt = '1')

        pdf.cell(-3)
        pdf.set_font('Arial','',9)
        a = str(df['SYSDATE_GENERATE'][i])
        a = a.split()
        a = a[0]
        pdf.cell(10,230,txt = str(a))

        pdf.cell(14)
        pdf.set_font('Arial','',9)
        pdf.cell(10,230,txt = str(df['MEMO_ITEM'][i]))

        pdf.cell(42)
        pdf.cell(10,230,txt = '6.00')

        pdf.cell(12)
        pdf.cell(10,230,txt = str(df['MEMO_AMOUNT'][i]))

        pdf.cell(16)
        pdf.cell(10,230,txt = str(df['GST_TAX'][i]))

        pdf.cell(14)
        pdf.cell(10,230,txt = str(df['TOTAL_AMOUNT_INCLUDED_GST'][i]))

        pdf.ln(1)
        pdf.set_line_width(0.1)
        pdf.line(20,150,190,150)


        pdf.ln(1)
        pdf.set_font('Arial','B',9)
        pdf.cell(88)
        pdf.cell(10,260,txt = 'TOTAL :')

        pdf.cell(16)
        pdf.cell(10,260,txt = str(df['MEMO_AMOUNT'][i]))

        pdf.cell(16)
        pdf.cell(10,260,txt = str(df['GST_TAX'][i]))

        pdf.cell(14)
        pdf.cell(10,260,txt = str(df['TOTAL_AMOUNT_INCLUDED_GST'][i]))

        pdf.ln(1)
        pdf.cell(10)
        pdf.set_font('Arial','',9)
        pdf.cell(10,450,txt = 'AGENSI KAUNSELING DAN PENGURUSAN KREDIT TELAH DITUBUHKAN OLEH BANK NEGARA')

        pdf.ln(1)
        pdf.cell(10)
        pdf.cell(10,455,txt = 'MALAYSIA UNTUK MENYEDIAKAN PERKHIDMATAN PENGURUSAN KEWANGAN, KAUNSELING KREDIT')

        pdf.ln(1)
        pdf.cell(10)
        pdf.cell(10,460,txt = 'PENDIDIKAN KEWANGAN DAN PENSTRUKTURAN SEMULA PINJAMAN SECARA PERCUMA KEPADA')

        pdf.ln(1)
        pdf.cell(10)
        pdf.cell(10,465,txt = 'INDIVIDU. UNTUK MEMBUAT PERTANYAAN, SILA HUBUNGI TALIAN 1-800-88-2575')


        pdf.cell(30)
        pdf.cell(10,490,txt = 'This tax invoice is system generated. No signature is required.')

        pdf.ln(1)
        pdf.cell(120)
        pdf.set_font('Arial','',6)
        pdf.cell(10,502,txt= 'TaxInv 1404-1904_200422.csv-00000' + str(count))

        pdf.set_line_width(4)
        pdf.set_draw_color(r=128, g=128, b=128)
        pdf.line(x1=10, y1=290, x2=200, y2=290) 
        

        # pdf.ln(1)
        # pdf.cell(150)
        # pdf.set_font('Arial','',6)
        # pdf.set_text_color(r = 255,g=255,b=255)
        # pdf.cell(10,512,txt= 'www.mybsn.com.my')

        
        pdf.add_page()
        pdf.image('E:\IWOC\SOURCE\BSN_Reminder-01.jpg',-10,-10,230)

        # pdf.set_font('Arial','',7)
        # pdf.cell(10,280,txt = '00' + str(c))
        # c += 1
        pdf.ln(1)
        pdf.image('E:\IWOC\SOURCE\BSN_Reminder-02.jpg', 12,154,180)

        pdf.ln(1)
        new_code  = 'b' + str(count)
        pdf.image(r'E:\IWOC\barcode_for_tax\%s.png'%(new_code),30,203,70)
        
        

    
        pdf.cell(22)
        pdf.cell(10,412,txt = str(barcode_no1))
        

        # pdf.set_font('times','',7)
        # pdf.cell(26)
        # pdf.cell(10,412,txt = '00' + str(count))


        # pdf.set_font('times','',7)
        # pdf.cell(-5)
        # pdf.cell(10,412,txt ='(000)')

        
        # pdf.set_font('times','',7)
        # pdf.cell(-5)
        # pdf.cell(10,412,txt =' -P02 - 01')
        
        h = 430 
        if pd.notna(df['LNAME'][i]):
            pdf.ln(1)
            pdf.set_font('Arial','B',10)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['LNAME'][i]))

        if pd.notna(df['ADDR1'][i]):
            h = h + 6
            pdf.ln(1)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['ADDR1'][i]))

        if pd.notna(df['ADDR2'][i]):
            h = h  + 6
            pdf.ln(1)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['ADDR2'][i]))

        if pd.notna(df['ADDR3'][i]):
            h = h  + 6
            pdf.ln(1)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['ADDR3'][i]))

        if pd.notna(df['ADDR4'][i]):
            h = h  + 6
            pdf.ln(1)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['ADDR4'][i]))
        
        if pd.notna(df['POSTCD'][i]):
            h = h  + 6
            pdf.ln(1)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['POSTCD'][i]) + str(df['CITY'][i]))

        if pd.notna(df['STATECD'][i]):
            h = h  + 6
            pdf.ln(1)
            pdf.cell(22)
            pdf.cell(10,h,txt = str(df['STATECD'][i]))
        count = int(count)
        count += 1

    pdf.output(r'E:\IWOC\SOURCE\tax.pdf') 

import PyPDF2

pdf_in = open(r'E:\IWOC\SOURCE\tax.pdf', 'rb')
pdf_reader = PyPDF2.PdfFileReader(pdf_in)
pdf_writer = PyPDF2.PdfFileWriter()

for pagenum in range(pdf_reader.numPages):
    page = pdf_reader.getPage(pagenum)
    if pagenum % 2:
        page.rotateClockwise(180)
    pdf_writer.addPage(page)

pdf_out = open(r'E:\IWOC\OUTPUT\TAX\tax.pdf', 'wb')
pdf_writer.write(pdf_out)
pdf_out.close()
pdf_in.close()   